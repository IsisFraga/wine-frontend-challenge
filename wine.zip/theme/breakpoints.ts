export const breakpoints = {
  mobileOnly: `@media (max-width: 990px)`,
  desktopOnly: `@media (min-width: 991px)`,
};
