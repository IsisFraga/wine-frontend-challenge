export enum FilterCodes {
  winesOnly = 'cVINHOS',
  perPrice = 'prBRL_'
}

export enum FiltersTypes {
  Price, WinesOnly
}