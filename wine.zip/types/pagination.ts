export interface Pagination {
  page: number;
  totalPages: number;
  itemsPerPage: number;
  totalItems: number;
}